//
//  LikeDataSource.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 6.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import Foundation
import Alamofire

protocol LikeDataDelegate{
    func onFailure()
    func onSuccess()
}

class LikeDataSource{
    let material: Material
    let user: User
    
    var delegate: LikeDataDelegate?
    
    init(material: Material, user: User){
        self.material = material
        self.user = user
    }
    
    func like(){
        send(type: HTTPMethod.post)
    }
    
    func unlike(){
        send(type: HTTPMethod.delete)
    }
    
    private func send(type: HTTPMethod){
        let parameters = ["material": material.id, "owner": user.id]
        Alamofire.request(Api.feedbackUrl, method: type, parameters: parameters).responseJSON() {
            (response) in
            let statusCode = response.response?.statusCode
            
            statusCode == 200 ? self.delegate!.onSuccess() : self.delegate!.onFailure()
        }
    }
}
