//
//  FeedbackView.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 2.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class FeedbackView{
    let material: Material
    var feedbackLabel: UILabel
    var feedbackSliderLabel: UILabel
    
    init(material: Material, feedbackLabel: UILabel, feedbackSliderLabel: UILabel) {
        self.material = material
        self.feedbackLabel = feedbackLabel
        self.feedbackSliderLabel = feedbackSliderLabel
        self.animateFeedbackLabel(to: material.feedback!)
    }
    
    func changeSliderLabel(to: Int){
        UIView.transition(with: feedbackSliderLabel,duration: 0.25,options: [.transitionCrossDissolve],animations: {
            self.feedbackSliderLabel.text = "\(to)"
        }, completion: nil)
    }
    
    func animateFeedbackLabel(to: Double) {
        DispatchQueue.global().async {
            self.sleep(multiplier: to)
            var i = 0.0
            while i < to{
                self.changeFeedbackLabel(to: i)
                i += 0.1
            }
            self.changeFeedbackLabel(to: i)
        }
    }

    private func changeFeedbackLabel(to: Double){
        self.sleep(multiplier: to)
        DispatchQueue.main.async {
            self.feedbackLabel.text = "\(to)"
            self.changeLabelColor(label: self.feedbackLabel, value: to)
        }
    }
    
    private func changeLabelColor(label: UILabel, value: Double){
        if value < 1{
            label.textColor = UIColor.red
        }
        else if value < 2{
            label.textColor = UIColor.orange
        }
        else if value < 3{
            label.textColor = UIColor.yellow
        }
        else{
            label.textColor = UIColor.green
        }
    }
    
    private func sleep(multiplier: Double){
        let sleepTime = UInt32(multiplier * 10000)
        usleep(sleepTime)
    }
}
