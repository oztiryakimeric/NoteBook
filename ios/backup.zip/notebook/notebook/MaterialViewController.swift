//
//  MaterialViewController.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 1.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class MaterialViewController: UIViewController, UIScrollViewDelegate, UITableViewDelegate, UITableViewDataSource, MaterialDataDelegate{
    var material: Material?
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var headerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var headerSpaceTopSpace: NSLayoutConstraint!
   
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var headerViewStack: UIStackView!
    var headerViewController: HeaderView?
    
    @IBOutlet weak var feedbackLabel: UILabel!
    @IBOutlet weak var feedbackSliderLabel: UILabel!
    var feedbackViewController: FeedbackView?
    
    @IBOutlet weak var usernameLabel2: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!

    @IBOutlet weak var favoriteCountLabel: UILabel!
    @IBOutlet weak var commentCountLabel: UILabel!
    
    
    @IBOutlet weak var commentTableView: UITableView!
    
    var dataSource: MaterialDataSource?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSource = MaterialDataSource(material: material!)
        dataSource?.dataDelegate = self
        dataSource?.commentSource.getInitialComments()
        
        headerViewController = HeaderView(material: material!,
                                          scrollView: scrollView,
                                          view: headerView,
                                          stack: headerViewStack,
                                          headerLabel: headerLabel,
                                          usernameLabel: usernameLabel,
                                          heightConstraint: headerViewHeight,
                                          topSpaceConstraint: headerSpaceTopSpace)
        feedbackViewController = FeedbackView(material: material!, feedbackLabel: feedbackLabel, feedbackSliderLabel: feedbackSliderLabel)
        
        initializeLabels()
    }
    
    private func initializeLabels(){
        usernameLabel2.text = "@\(material!.ownerUser)"
        descriptionLabel.text = material!.description
        favoriteCountLabel.text = "\(material!.favoriteCount!)"
        commentCountLabel.text = "\(material!.commentCount!)"
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let scroll = self.scrollView.contentOffset.y
        
        if (headerViewController?.isPageGoesDown())!{
            if scroll < 50{
                headerViewController?.shrinkHeaderView(value: scroll)
            }
            else if scroll < 100{
                headerViewController?.shrinkHeaderViewToMin()
            }
                
            else if (headerViewController?.isHeaderShrinked)! && scroll > 100{
                headerViewController?.shrinkHeaderViewToMin()
            }
        }
        
        if (headerViewController?.isPageGoesUp())!{
            if scroll < 50{
                headerViewController?.expandHeaderViewToMax()
            }
            else if scroll < 100{
                headerViewController?.expandHeaderView(value: scroll)
            }
            else if !(headerViewController?.isHeaderShrinked)! && scroll > 100{
                headerViewController?.expandHeaderViewToMax()
            }
        }
        headerViewController?.lastPosition = scroll
    }
    
    @IBAction func onFeedbackValueChanged(_ sender: Any) {
        let currentValue = Int((sender as! UISlider).value)
        feedbackViewController?.changeSliderLabel(to: currentValue)
    }
    
    @IBAction func onGiveFeedbackButtonPressed(_ sender: Any) {
        dataSource?.sendFeedback(point: Int(feedbackSliderLabel.text!)!)
    }
    
    func feedbackUpdated(to: Double) {
        feedbackViewController?.animateFeedbackLabel(to: to)
    }
    
    func commentDataUpdated() {
        self.commentTableView.reloadData()
    }
    
    @IBAction func onGetFileClicked(_ sender: Any) {
        print("Go to \(material!.fileUrl)")
        let url = URL(string: Api.classListUrl)
        UIApplication.shared.open(url!, options: [:], completionHandler: {
            (success) in
            print("Open \(url!): \(success)")
        })
    }
    
    @IBAction func onLikeClicked(_ sender: Any) {
        print("Like Clicked")
    }
    
    func liked() {
        
    }
    
    @IBAction func onCommentClicked(_ sender: Any) {
        print("Comment Clicked")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dataSource?.commentSource.commentList.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "comment_view_cell", for: indexPath) as! CommentCell
        
        let comment = dataSource?.commentSource.giveComment(indexPath: indexPath)
        
        cell.username.text = comment?.owner
        cell.comment.text = comment?.comment
        
        return cell
    }
}
