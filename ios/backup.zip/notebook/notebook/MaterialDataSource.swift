//
//  MaterialDataSource.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 2.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import Foundation
import Alamofire
import Unbox

@objc protocol MaterialDataDelegate{
    @objc optional func commentDataUpdated()
    @objc optional func feedbackUpdated(to: Double)
    @objc optional func liked()
}

class MaterialDataSource{
    let material: Material
    
    var dataDelegate: MaterialDataDelegate?
    
    var commentSource = CommentSource()
    
    init(material: Material) {
        self.material = material
        commentSource.parent = self
    }
    
    class NewItem{
        func postNewMaterial(material: Material){
            Alamofire.request(Api.feedbackUrl, method: .post, parameters: material.toJson()).responseJSON() { (response) in
                print(response)
            }
        }
    }
    
    func sendFeedback(point: Int){
        print("Feedback sending...")
        
        let parameters = ["material": material.id, "point": point]
        Alamofire.request(Api.feedbackUrl, method: .post, parameters: parameters).responseJSON() {
            (response) in
            
            if let result = response.result.value {
                let JSON = result as! NSDictionary
                self.dataDelegate?.feedbackUpdated!(to: JSON["average"] as! Double)
            }
        }
    }
    
    class CommentSource{
        weak var parent: MaterialDataSource! = nil
        var commentList: [Comment] = []
        var currentPage = 2
        var isLoading = false
        
        func getInitialComments(){
            getCommentsAtPage(page: 1)
        }
        
        func getNextPage(){
            let olCount = commentList.count
            getCommentsAtPage(page: currentPage)
            if(olCount != commentList.count){
                currentPage += 1
            }
        }
        
        private func getCommentsAtPage(page: Int){
            isLoading = true
            let parameters = ["page": page, "material_code": parent.material.id]
            
            Alamofire.request(Api.commentUrl, method: .get, parameters: parameters).responseJSON() {
                (response) in
                do{
                    self.commentList.append(contentsOf: try unbox(data:response.data!))
                    self.parent.dataDelegate?.commentDataUpdated!()
                    self.isLoading = false
                }catch{
                    print("Error while downloading")
                }
            }
        }
        
        func giveComment(indexPath: IndexPath) -> Comment{
            return commentList[indexPath.row]
        }
    }
}
