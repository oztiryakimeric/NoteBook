//
//  HeaderView.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 2.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class HeaderView{
    let material: Material
    var scrollView: UIScrollView
    var view: UIView
    var stack: UIStackView
    var headerLabel: UILabel
    var usernameLabel: UILabel
    
    var heightConstraint: NSLayoutConstraint
    var topSpaceConstraint: NSLayoutConstraint
    
    var isHeaderShrinked: Bool = false
    var lastPosition: CGFloat = 0
    
    init(material: Material, scrollView: UIScrollView, view: UIView, stack: UIStackView, headerLabel: UILabel, usernameLabel: UILabel, heightConstraint: NSLayoutConstraint, topSpaceConstraint: NSLayoutConstraint) {
        self.material = material
        self.scrollView = scrollView
        self.view = view
        self.stack = stack
        self.headerLabel = headerLabel
        self.usernameLabel = usernameLabel
        self.heightConstraint = heightConstraint
        self.topSpaceConstraint = topSpaceConstraint
        self.view.backgroundColor = Color.orange
        self.setLabelTexts()
    }
    
    private func setLabelTexts(){
        headerLabel.text = material.header
        usernameLabel.text = "@\(material.ownerUser)"
    }
    
    func shrinkHeaderView(value: CGFloat){
        self.heightConstraint.constant =  150 - value
        self.topSpaceConstraint.constant = 45 - value/3
        self.view.layoutIfNeeded()
        isHeaderShrinked = true
    }
    
    func shrinkHeaderViewToMin(){
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 5, options: [.allowUserInteraction, .curveEaseInOut], animations: {
            self.heightConstraint.constant =  50
            self.topSpaceConstraint.constant = 11
            self.stack.axis = .horizontal
            self.view.layoutIfNeeded()
        }, completion: nil)
        isHeaderShrinked = true
    }
    
    func expandHeaderView(value: CGFloat){
        self.heightConstraint.constant =  150 - value
        self.topSpaceConstraint.constant = 45 - value/3
        self.view.layoutIfNeeded()
        isHeaderShrinked = false
    }
    
    func expandHeaderViewToMax(){
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 5, options:  [.allowUserInteraction, .curveEaseInOut], animations: {
            self.heightConstraint.constant =  150
            self.topSpaceConstraint.constant = 45
            self.stack.axis = .vertical
            self.view.layoutIfNeeded()
        }, completion: nil)
        isHeaderShrinked = false
    }
    
    func isPageGoesDown() -> Bool{
        let scroll = scrollView.contentOffset.y
        return scroll > 0 && scroll > lastPosition
    }
    
    func isPageGoesUp() -> Bool{
        let scroll = scrollView.contentOffset.y
        return scroll > 0 && scroll < lastPosition
    }
}
