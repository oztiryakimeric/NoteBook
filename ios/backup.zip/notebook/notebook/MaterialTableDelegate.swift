//
//  MaterialListDelegate.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 5.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class MaterialTableDelegate: NSObject, UITableViewDataSource, UITableViewDelegate{
    
    let dataSource: MaterialListDataSource
    
    init(dataSource: MaterialListDataSource) {
        self.dataSource = dataSource
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.materialList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "material_view_cell", for: indexPath) as! MaterialCell
        
        let material = dataSource.giveMaterial(indexPath: indexPath)
        
        cell.headerLabel.text = material.header
        cell.descriptionLabel.text = material.description
        cell.usernameLabel.text = "@\(material.ownerUser)"
        cell.favoriteCountLabel.text = "\(material.favoriteCount!)"
        cell.commentCountLabel.text = "\(material.commentCount!)"
        cell.feedbackLabel.text = "\(Int(material.feedback!))"
        
        return cell
    }
}
