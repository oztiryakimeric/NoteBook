//
//  MaterialListDataSource.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 30.04.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import Foundation
import Alamofire
import Unbox

@objc protocol MaterialListDataDelegate{
    @objc optional func onDataUpdate();
}

enum HolderType{
    case User, Class
}

class MaterialListDataSource{
    let dataDelegate: MaterialListDataDelegate
    let holder: Any
    
    var materialList: [Material] = []
    var currentPage = 2
    var isLoading = false
    
    var holderKey: [String: Int]{
        return (holder is Class ? ["class_code": giveClassId()] : ["user_code": giveUserId()])
    }
    
    init(holder: Any, delegate: MaterialListDataDelegate){
        self.holder = holder
        self.dataDelegate = delegate;
    }
    
    func getInitialMaterialList(){
        getMaterialsAtPage(page: 1)
    }
    
    func reloadData(){
        materialList.removeAll()
        dataDelegate.onDataUpdate!()
        getMaterialsAtPage(page: 1)
    }
    
    func getNextPage(){
        let oldCount = materialList.count
        getMaterialsAtPage(page: currentPage)
        if(oldCount != materialList.count){
            currentPage += 1
        }
    }
    
    private func getMaterialsAtPage(page: Int){
        isLoading = true
        
        var parameters = ["page": page]
        for (key,value) in holderKey {
            parameters.updateValue(value, forKey:key)
        }

        Alamofire.request(Api.materialUrl, method: .get, parameters: parameters).responseJSON() {
            (response) in
            do{
                self.materialList.append(contentsOf: try unbox(data:response.data!))
                self.dataDelegate.onDataUpdate!()
                self.isLoading = false
            }catch{
                print("Error while downloading")
            }
        }
    }
    
    func giveMaterial(indexPath: IndexPath) -> Material{
        return materialList[indexPath.row]
    }
    
    private func giveClassId() -> Int{
        return (holder as! Class).id
    }
    
    private func giveUserId() -> Int{
        return (holder as! User).id!
    }
}
