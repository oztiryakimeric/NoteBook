//
//  SecondViewController.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 15.04.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var likeButton: LikeButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

