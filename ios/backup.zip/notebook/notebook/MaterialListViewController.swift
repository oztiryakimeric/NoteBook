//
//  MaterialListViewController.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 30.04.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

class MaterialListViewController: UIViewController, MaterialListDataDelegate, MaterialDialogDelegate {

    var holder: Any?
    var dataSource: MaterialListDataSource?
    var tableDelegate: MaterialTableDelegate?
    
    var isDialogShown: Bool = false
    
    @IBOutlet weak var materialListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource = MaterialListDataSource(holder: holder!, delegate: self)
        dataSource?.getInitialMaterialList()
        
        tableDelegate = MaterialTableDelegate(dataSource: dataSource!)
        materialListTableView.dataSource = tableDelegate
        materialListTableView.delegate = tableDelegate
        
        addNewMaterialButton()
    }
    
    func onDataUpdate() {
        materialListTableView.reloadData()
    }
    
    @objc func onAddMaterialButtonClicked() {
        if !isDialogShown{
            let dialog = MaterialDialog.create(superView: self.view, _class: holder as! Class)
            dialog.delegate = self
            dialog.show()
            isDialogShown = true
        }
    }
    
    func onDialogClose() {
        isDialogShown = false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let selectedCell = sender as! MaterialCell
        
        let indexPath = self.materialListTableView.indexPath(for: selectedCell)
        
        let controller = segue.destination as! MaterialViewController
        
        controller.material = dataSource?.giveMaterial(indexPath: indexPath!)
    }
    
    private func addNewMaterialButton(){
        if(holder! is Class){
            let addMaterialButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(MaterialListViewController.onAddMaterialButtonClicked))
            self.navigationItem.setRightBarButtonItems([addMaterialButton], animated: false)
        }
    }
}
