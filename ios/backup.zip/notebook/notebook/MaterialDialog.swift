//
//  CreateMaterialView.swift
//  notebook
//
//  Created by Meriç Öztiryaki on 3.05.2017.
//  Copyright © 2017 Meriç Öztiryaki. All rights reserved.
//

import UIKit

protocol MaterialDialogDelegate{
    func onDialogClose()
}

class MaterialDialog: UIView {
    var delegate: MaterialDialogDelegate?
    
    var parent: UIView?
    var material: Material?
    var _class: Class?
    
    var effectHolder: UIVisualEffect?
    @IBOutlet weak var blurEffect: UIVisualEffectView!
    @IBOutlet weak var mainRect: UIView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var headerTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var fileUrlTextField: UITextField!
    
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.mainRect.layer.cornerRadius = 15
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    static func create(superView: UIView, _class: Class) -> MaterialDialog{
        let view = Bundle.main.loadNibNamed("MaterialDialog", owner: self, options: nil)?.first as! MaterialDialog
        view.initialize(parent: superView, _class: _class)
        view.cropCorners()
        return view
    }
    
    static func update(superView: UIView, material: Material) -> MaterialDialog{
        let view = Bundle.main.loadNibNamed("MaterialDialog", owner: self, options: nil)?.first as! MaterialDialog
        view.initialize(parent: superView, material: material)
        view.cropCorners()
        return view
    }
    
    private func initialize(parent: UIView, _class: Class){
        self.parent = parent
        self._class = _class
        self.frame = CGRect(x: 0, y: 0, width: parent.frame.width, height: parent.frame.height)
        holdEffect()
    }
    
    private func initialize(parent: UIView, material: Material){
        self.parent = parent
        self.material = material
        self.frame = CGRect(x: 0, y: 0, width: parent.frame.width, height: parent.frame.height)
        prepareDialogForUpdate()
        holdEffect()
    }
    
    func show(){
        let window = UIApplication.shared.keyWindow!
        window.addSubview(self);
        
        self.alpha = 0
        self.transform = CGAffineTransform.init(scaleX: 1.4, y: 1.4)
        
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 5, options: .curveEaseInOut, animations: {
            self.alpha = 1
            self.transform = CGAffineTransform.identity
            self.blurEffect.effect = self.effectHolder
        }, completion: nil)
    }
    
    private func remove(){
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 5, options: .curveEaseInOut, animations: {
            self.alpha = 0
            self.transform = CGAffineTransform.init(scaleX: 1.4, y: 1.4)
            self.blurEffect.effect = nil
        }) { (success) in
            self.removeFromSuperview()
        }
    }
    
    private func cropCorners(){
        mainRect.layer.cornerRadius = 15
        titleLabel.layer.cornerRadius = 15
        cancelButton.layer.cornerRadius = 15
        doneButton.layer.cornerRadius = 15
    }
    
    private func holdEffect(){
        effectHolder = blurEffect.effect
        blurEffect.effect = nil
    }
    
    private func prepareDialogForUpdate(){
        titleLabel.text = "Update Material"
        headerTextField.placeholder = material!.header
        descriptionTextField.placeholder = material!.description
        fileUrlTextField.placeholder = material!.description
    }
    
    @IBAction func onCancelButtonClicked(_ sender: Any) {
        remove()
        delegate?.onDialogClose()
    }
    
    @IBAction func onDoneButtonClicked(_ sender: Any) {
        var material: Material
        if (_class != nil){
            material = Material(ownerClass: (_class!.id), ownerUser: "1", header: headerTextField.text!, description: descriptionTextField.text!, fileUrl: fileUrlTextField.text!)
        }
        else{
            material = Material(ownerClass: self.material!.ownerClass, ownerUser: "1", header: headerTextField.text!, description: descriptionTextField.text!, fileUrl: fileUrlTextField.text!)
        }
        
        //MaterialDataSource.NewItem.postNewMaterial(material)
    }
}








